# Simple Pattern Clicker

这是一个独立的极简版本：按固定周期捕获覆盖所有显示器的虚拟桌面，用 OpenCV 检测是否出现指定 pattern；找到后点击匹配区域中心，未找到则等待下一轮。程序会把每个 pattern 最近一次点击位置保存到 `pattern_position_cache.json`，下一轮优先在该位置附近检测，失败后再扫描全屏。

## 运行

```powershell
python -m pip install -r requirements.txt
python main.py
```

在窗口中选择一张 pattern 图片，设置检测周期和相似度后点击“启动”。关闭窗口会隐藏到系统托盘；通过托盘菜单可恢复窗口、暂停/继续或退出。
