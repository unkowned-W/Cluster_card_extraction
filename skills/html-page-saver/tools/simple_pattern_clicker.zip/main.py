from __future__ import annotations

import os
import sys
import time
import json
from dataclasses import dataclass

import cv2
import mss
import numpy as np
import pyautogui
from PySide6.QtCore import QObject, QThread, Signal, Slot, Qt
from PySide6.QtGui import QAction, QCloseEvent
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QDoubleSpinBox,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QStyle,
    QSystemTrayIcon,
    QVBoxLayout,
    QWidget,
)


@dataclass(frozen=True)
class DetectorConfig:
    pattern_path: str
    interval_seconds: float
    confidence: float


class PatternWorker(QObject):
    status = Signal(str)
    found = Signal(float, int, int)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, config: DetectorConfig):
        super().__init__()
        self.config = config
        self._running = True
        self._cache_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pattern_position_cache.json")
        self._cache_key = os.path.abspath(config.pattern_path)

    def _load_cached_position(self) -> tuple[int, int] | None:
        try:
            with open(self._cache_path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            point = payload.get(self._cache_key)
            if isinstance(point, list) and len(point) == 2:
                return int(point[0]), int(point[1])
        except (OSError, ValueError, TypeError):
            pass
        return None

    def _save_cached_position(self, x: int, y: int) -> None:
        payload = {}
        try:
            with open(self._cache_path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
                if isinstance(loaded, dict):
                    payload = loaded
        except (OSError, ValueError, TypeError):
            pass
        payload[self._cache_key] = [int(x), int(y)]
        try:
            with open(self._cache_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
        except OSError:
            # 缓存失败不应影响检测与点击。
            pass

    @staticmethod
    def _match(frame: np.ndarray, template: np.ndarray, confidence: float):
        frame_h, frame_w = frame.shape[:2]
        template_h, template_w = template.shape[:2]
        if template_h > frame_h or template_w > frame_w:
            return None
        result = cv2.matchTemplate(frame, template, cv2.TM_CCOEFF_NORMED)
        _, score, _, location = cv2.minMaxLoc(result)
        if score < confidence:
            return None
        return float(score), int(location[0]), int(location[1])

    @Slot()
    def run(self) -> None:
        try:
            template = cv2.imread(self.config.pattern_path, cv2.IMREAD_GRAYSCALE)
            if template is None or template.size == 0:
                raise ValueError("无法读取 pattern 图片")
            template_h, template_w = template.shape[:2]
            cached_position = self._load_cached_position()
            self.status.emit("正在检测（支持多屏）")

            with mss.mss() as screen:
                virtual = screen.monitors[0]
                while self._running:
                    started = time.monotonic()
                    match = None
                    source = "全屏"

                    # mss.monitors[0] 是覆盖所有显示器的虚拟桌面，支持负坐标副屏。
                    if cached_position is not None:
                        radius = max(240, max(template_w, template_h) * 2)
                        cx, cy = cached_position
                        left = max(virtual["left"], cx - radius - template_w // 2)
                        top = max(virtual["top"], cy - radius - template_h // 2)
                        right = min(virtual["left"] + virtual["width"], cx + radius + template_w // 2)
                        bottom = min(virtual["top"] + virtual["height"], cy + radius + template_h // 2)
                        region = {
                            "left": left,
                            "top": top,
                            "width": max(1, right - left),
                            "height": max(1, bottom - top),
                        }
                        cached_frame = cv2.cvtColor(np.asarray(screen.grab(region)), cv2.COLOR_BGRA2GRAY)
                        match = self._match(cached_frame, template, self.config.confidence)
                        source = "缓存附近"
                        if match is not None:
                            score, local_x, local_y = match
                            match = (score, local_x + left, local_y + top)

                    if match is None:
                        full_frame = cv2.cvtColor(np.asarray(screen.grab(virtual)), cv2.COLOR_BGRA2GRAY)
                        full_match = self._match(full_frame, template, self.config.confidence)
                        if full_match is not None:
                            score, local_x, local_y = full_match
                            match = (score, local_x + virtual["left"], local_y + virtual["top"])
                            source = "全屏"

                    if match is not None:
                        score, match_x, match_y = match
                        x = int(match_x + template_w / 2)
                        y = int(match_y + template_h / 2)
                        pyautogui.click(x, y)
                        cached_position = (x, y)
                        self._save_cached_position(x, y)
                        self.found.emit(float(score), x, y)
                        self.status.emit(f"已点击（{source}）")
                    else:
                        self.status.emit("未找到，等待下一轮")

                elapsed = time.monotonic() - started
                remaining = max(0.0, self.config.interval_seconds - elapsed)
                end = time.monotonic() + remaining
                while self._running and time.monotonic() < end:
                    time.sleep(min(0.1, end - time.monotonic()))
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()

    def stop(self) -> None:
        self._running = False


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Simple Pattern Clicker")
        self.setMinimumWidth(520)
        self._thread: QThread | None = None
        self._worker: PatternWorker | None = None
        self._allow_close = False
        self._build_ui()
        self._build_tray()

    def _build_ui(self) -> None:
        root = QWidget()
        layout = QVBoxLayout(root)
        form = QFormLayout()

        self.pattern_label = QLabel("未选择")
        self.pattern_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        choose = QPushButton("选择图片…")
        choose.clicked.connect(self.choose_pattern)
        pattern_row = QHBoxLayout()
        pattern_row.addWidget(self.pattern_label, 1)
        pattern_row.addWidget(choose)
        form.addRow("Pattern", pattern_row)

        self.interval_spin = QDoubleSpinBox()
        self.interval_spin.setRange(0.1, 3600.0)
        self.interval_spin.setSingleStep(0.5)
        self.interval_spin.setValue(2.0)
        self.interval_spin.setSuffix(" 秒")
        form.addRow("检测周期", self.interval_spin)

        self.confidence_spin = QDoubleSpinBox()
        self.confidence_spin.setRange(0.1, 1.0)
        self.confidence_spin.setSingleStep(0.01)
        self.confidence_spin.setValue(0.85)
        self.confidence_spin.setDecimals(2)
        form.addRow("相似度阈值", self.confidence_spin)
        layout.addLayout(form)

        buttons = QHBoxLayout()
        self.start_button = QPushButton("启动")
        self.start_button.clicked.connect(self.start_detection)
        self.stop_button = QPushButton("停止")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_detection)
        buttons.addWidget(self.start_button)
        buttons.addWidget(self.stop_button)
        layout.addLayout(buttons)

        self.status_label = QLabel("状态：已停止")
        self.status_label.setStyleSheet("font-weight: 600;")
        self.detail_label = QLabel("选择 pattern 图片后开始")
        self.detail_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        layout.addWidget(self.detail_label)
        layout.addStretch(1)
        self.setCentralWidget(root)

    def _build_tray(self) -> None:
        icon = self.style().standardIcon(QStyle.SP_ComputerIcon)
        self.tray = QSystemTrayIcon(icon, self)
        self.tray.setToolTip("Simple Pattern Clicker：已停止")
        menu = QMenu()
        show_action = QAction("显示窗口", self)
        show_action.triggered.connect(self.show_from_tray)
        menu.addAction(show_action)
        self.tray_toggle_action = QAction("启动", self)
        self.tray_toggle_action.triggered.connect(self.toggle_detection)
        menu.addAction(self.tray_toggle_action)
        menu.addSeparator()
        quit_action = QAction("退出", self)
        quit_action.triggered.connect(self.quit_app)
        menu.addAction(quit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()

    def choose_pattern(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择 pattern 图片",
            "",
            "图片 (*.png *.jpg *.jpeg *.bmp *.webp)",
        )
        if path:
            self.pattern_label.setText(path)
            self.detail_label.setText("已选择 pattern，点击“启动”开始检测")

    def start_detection(self) -> None:
        path = self.pattern_label.text()
        if path == "未选择" or not os.path.isfile(path):
            QMessageBox.warning(self, "缺少 pattern", "请先选择有效的 pattern 图片。")
            return
        if self._thread is not None:
            return

        config = DetectorConfig(path, self.interval_spin.value(), self.confidence_spin.value())
        self._thread = QThread(self)
        self._worker = PatternWorker(config)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.status.connect(self.on_status)
        self._worker.found.connect(self.on_found)
        self._worker.failed.connect(self.on_failed)
        self._worker.finished.connect(self._thread.quit)
        self._worker.finished.connect(self._worker.deleteLater)
        self._thread.finished.connect(self._thread.deleteLater)
        self._thread.finished.connect(self._worker_finished)
        self._thread.start()
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.tray_toggle_action.setText("停止")
        self._set_status("运行中")

    def stop_detection(self) -> None:
        if self._worker is not None:
            self._worker.stop()
        self.stop_button.setEnabled(False)
        self._set_status("正在停止…")

    def _worker_finished(self) -> None:
        self._worker = None
        self._thread = None
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.tray_toggle_action.setText("启动")
        if not self.status_label.text().endswith("错误"):
            self._set_status("已停止")

    @Slot(str)
    def on_status(self, message: str) -> None:
        self.detail_label.setText(message)

    @Slot(float, int, int)
    def on_found(self, score: float, x: int, y: int) -> None:
        self._set_status("已点击")
        self.detail_label.setText(f"找到 pattern，相似度 {score:.3f}，点击位置 ({x}, {y})")

    @Slot(str)
    def on_failed(self, message: str) -> None:
        self._set_status("错误")
        self.detail_label.setText(message)
        self.tray.showMessage("Pattern Clicker", message, QSystemTrayIcon.Critical, 4000)

    def _set_status(self, status: str) -> None:
        self.status_label.setText(f"状态：{status}")
        self.tray.setToolTip(f"Simple Pattern Clicker：{status}")

    def toggle_detection(self) -> None:
        if self._thread is None:
            self.start_detection()
        else:
            self.stop_detection()

    def show_from_tray(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason == QSystemTrayIcon.DoubleClick:
            self.show_from_tray()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._allow_close:
            self.stop_detection()
            event.accept()
            return
        event.ignore()
        self.hide()
        self.tray.showMessage("Pattern Clicker", "程序已隐藏到系统托盘", QSystemTrayIcon.Information, 2000)

    def quit_app(self) -> None:
        self._allow_close = True
        self.stop_detection()
        if self._thread is not None:
            self._thread.quit()
            self._thread.wait(1500)
        QApplication.quit()


def main() -> int:
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
